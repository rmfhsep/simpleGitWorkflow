const getListMultiplesOfTwo = require('./getListMultiplesOfTwo'); // getListMultiplesOfTwo.js 파일을 불러옵니다

console.log('100 미만의 2의 배수는 다음과 같습니다.');
console.log(getListMultiplesOfTwo(100));